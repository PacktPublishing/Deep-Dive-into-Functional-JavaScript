const square = x => x ** 2;
console.log( [1, 2, 3, 4].map( square ) );


const nodeList = [5, 2, 4];

const node = {
    value: 5,
    left: {
        value: 2,
        left: null,
        right: {
            value: 4,
            left: null,
            right: null
        }
    },
    right: null  
};